#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>

#define PORT 7243
#define BUFFER_SIZE 1024
#define BASE_DIR "." // Default directory of servers root
#define INDEX_NAME "index.html" // Index name for automaticaly redrect '.../' to '.../index.html'

void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    int bytes_read = read(client_socket, buffer, sizeof(buffer) - 1);
    if (bytes_read < 0) {
        perror("Failed to read from socket");
        close(client_socket);
        return;
    }

    // Null-terminate the received data
    buffer[bytes_read] = '\0';

    // Print the received request (for debugging)
    printf("Received request:\n%s\n", buffer);

    // Extract the requested file path
    char *request_line = strtok(buffer, "\r\n");
    if (request_line == NULL) {
        close(client_socket);
        return;
    }

    char method[16], path[256];
    sscanf(request_line, "%s %s", method, path);
    
    if (strcmp(method, "GET") != 0) {
        close(client_socket);
        return;
    }
    // Remove the leading '/' from the path
    if (path[0] == '/') {
        memmove(path, path + 1, strlen(path));
    }

    // Construct the full file path
    char full_path[512], full_path_i[512];
    snprintf(full_path_i, sizeof(full_path_i), "%s/%s/%s", BASE_DIR, path, INDEX_NAME);
    snprintf(full_path, sizeof(full_path), "%s/%s", BASE_DIR, path);

    // Check if the requested file exists
    struct stat file_stat;
    if (stat(full_path_i, &file_stat) == 0)
    {
        strcpy(full_path, full_path_i);
    }

    if(stat(full_path, &file_stat) == 0) {
        // Open the requested file
        FILE *file = fopen(full_path, "rb");
        if (file != NULL) {
            // Read the file content
            fseek(file, 0, SEEK_END);
            long file_size = ftell(file);
            fseek(file, 0, SEEK_SET);

            char *file_content = malloc(file_size);
            fread(file_content, 1, file_size, file);

	    // Send the file content
            write(client_socket, file_content, file_size);

            // Clean up
            free(file_content);
            fclose(file);
        }
    }

    // Close the client socket
    close(client_socket);
}


int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Failed to create socket");
        exit(EXIT_FAILURE);
    }

    // Set up the server address structure
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY; // Listen on all interfaces
    server_addr.sin_port = htons(PORT); // Convert to network byte order

    // Bind the socket to the specified port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Failed to bind socket");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Start listening for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Failed to listen on socket");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    // Main loop to accept and handle incoming connections
    while (1) {
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Failed to accept connection");
            continue; // Continue to the next iteration
        }

        // Handle the client in a separate function
        handle_client(client_socket);
    }
    return 0;
}
