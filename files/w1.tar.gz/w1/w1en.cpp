#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

std::string processText(const std::string& str) {
    std::string result;
    std::istringstream stream(str);
    std::string line;
    int blankLineCount = 0; // Counter for consecutive blank lines

    while (std::getline(stream, line)) {
        // Remove leading spaces
        size_t start = line.find_first_not_of(" \t");
        if (start != std::string::npos) {
            line = line.substr(start); // Trim leading spaces
        } else {
            line.clear(); // If the line is all spaces, clear it
        }

        // Check if the line has more than one character
        if (line.length() > 2) {
            // Reset blank line count and add the processed line
            blankLineCount = 0; // Reset the counter for non-blank lines
            result += "    "; // Add four spaces
            result += line; // Add the processed line
            result += '\n'; // Add a newline after each processed line
        } else {
            // If the line is blank, increment the blank line counter
            if (line.empty()) {
                blankLineCount++;
                // Only add two blank lines maximum
                if (blankLineCount <= 2) {
                    result += '\n'; // Add a newline for blank lines
                }
            }
        }
    }

    return result;
}

std::string expandHTML(const std::string &input) {
    int indent_level = 0; // Current indentation level
    std::string output; // Output string

    for (size_t i = 0; i < input.length(); ++i) {
        // Check for the start of a tag
        if (input[i] == '<') {
            // If it's a closing tag, decrease the indent level
            if (input[i + 1] == '/') {
                indent_level--;
                output += '\n'; // Add a newline before the closing tag
                output.append(indent_level, '\t'); // Add indentation
            } else {
                // It's an opening tag, add a newline and indent
                output += '\n';
                output.append(indent_level, '\t'); // Add indentation
                // Check if it's a self-closing tag
                if (input[i + 1] != '!' && input[i + 1] != '?' && input[i + 1] != '/') {
                    indent_level++; // Increase indent level for opening tags
                }
            }
        }

        // Copy the character to output
        output += input[i];

        // If we just copied a closing tag, add a newline
        if (input[i] == '>') {
            output += '\n';
        }
    }

    return output; // Return the expanded HTML
}


std::string removeOtherTags(const std::string &input) {
    std::string output;
    bool inTag = false; // Flag to indicate if we are inside a tag

    for (char ch : input) {
        if (ch == '<') {
            inTag = true; // We are now inside a tag
        } else if (ch == '>') {
            inTag = false; // We are now outside a tag
        } else if (!inTag) {
            output += ch; // Only add characters that are not inside a tag
        }
    }

    return output; // Return the string without HTML tags
}

std::string removeTags(const std::string &html) {
    std::string modifiedHtml = html; // Create a copy of the original HTML
    size_t style_start, style_end;
    size_t script_start, script_end;

    // Remove <style>...</style>
    while ((style_start = modifiedHtml.find("<style")) != std::string::npos) {
        style_end = modifiedHtml.find("</style>", style_start);
        if (style_end == std::string::npos) break; // No closing tag found
        // Erase the <style>...</style> section
        modifiedHtml.erase(style_start, style_end - style_start + 8); // 8 is the length of "</style>"
    }

    // Remove <script>...</script>
    while ((script_start = modifiedHtml.find("<script")) != std::string::npos) {
        script_end = modifiedHtml.find("</script>", script_start);
        if (script_end == std::string::npos) break; // No closing tag found
        // Erase the <script>...</script> section
        modifiedHtml.erase(script_start, script_end - script_start + 9); // 9 is the length of "</script>"
    }

    return modifiedHtml; // Return the modified HTML
}

void printUsage(const char* programName) {
    std::cerr << "Usage: " << programName << " <filename>\n";
    std::cerr << "Reads the content from the specified file and removes HTML tags.\n";
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printUsage(argv[0]);
        return 1;
    }

    std::string filename = argv[1];
    std::ifstream inputFile(filename);
    
    if (!inputFile) {
        std::cerr << "Error: Could not open file " << filename << std::endl;
        return 1;
    }

    std::string original;
    std::string line;

    // Read the entire file content into the original string
    while (std::getline(inputFile, line)) {
        original += line + "\n"; // Add a newline to preserve line breaks
    }

    inputFile.close();

    std::cout << processText(removeOtherTags(expandHTML(removeTags(original)))) << std::endl;

    return 0;
}